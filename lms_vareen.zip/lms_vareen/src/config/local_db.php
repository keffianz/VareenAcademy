<?php
/**
 * Local development database credentials (XAMPP).
 * This file is ignored by Git and must not be committed.
 *
 * Configured for local testing against the XAMPP MySQL instance.
 * The demo_accounts.sql seed must be loaded for the login test accounts.
 */
return [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => 'localtest',
    'name' => 'u374397808_vereen_academy',
];

