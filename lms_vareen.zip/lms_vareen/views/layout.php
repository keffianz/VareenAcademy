<?php
/**
 * Main Layout Template
 * Wraps all views with proper HTML structure
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo csrfToken(); ?>">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>VAREEN Academy LMS</title>
    
    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo appBasePath() . '/public/css/styles.css'; ?>">
    <?php if (isset($_SESSION['role'])): ?>
    <!-- Dashboard shell (sidebar, topbar, KPI cards) — logged-in roles only.
         Loaded AFTER styles.css so dashboard rules win the cascade for shared
         class names (.btn, .alert), and BEFORE responsive.css so media-query
         overrides always take precedence. -->
    <link rel="stylesheet" href="<?php echo appBasePath() . '/public/css/dashboard.css'; ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo appBasePath() . '/public/css/responsive.css'; ?>">

    <!-- Font Awesome (sidebar/KPI/button icons across all dashboards) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <!-- AI Assistant Widget CSS (only for students) -->
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'student'): ?>
        <link rel="stylesheet" href="<?php echo appBasePath() . '/public/css/ai-assistant.css'; ?>">
    <?php endif; ?>
    
    <!-- Additional CSS can be added here per page -->
    <?php if (!empty($additional_css)): ?>
        <?php foreach ($additional_css as $css): ?>
            <link rel="stylesheet" href="<?php echo htmlspecialchars($css); ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <!-- Page Content -->
    <div class="page-wrapper">
        <?php
        // The actual view content is output here
        // This is set by the router before including the layout
        if (isset($view_content)) {
            echo $view_content;
        }
        ?>
    </div>
    
    <!-- JavaScript Files -->
    <script src="<?php echo appBasePath() . '/public/js/main.js'; ?>"></script>
    
    <!-- AI Assistant Widget JS (only for students) -->
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'student'): ?>
        <script src="<?php echo appBasePath() . '/public/js/ai-assistant.js'; ?>"></script>
    <?php endif; ?>
    
    <!-- Admin shared JS (sidebar toggle + scrim, logout, KPIs) — all dashboard roles -->
    <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin','teacher','student'], true)): ?>
        <script src="<?php echo appBasePath() . '/public/js/admin.js'; ?>"></script>
    <?php endif; ?>
    
    <!-- Command Palette (admin & teacher roles only) -->
    <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin','teacher'], true)): ?>
        <script src="<?php echo appBasePath() . '/public/js/command-palette.js'; ?>"></script>
    <?php endif; ?>
    
    <!-- Additional JS can be added here per page -->
    <?php if (!empty($additional_js)): ?>
        <?php foreach ($additional_js as $js): ?>
            <script src="<?php echo htmlspecialchars($js); ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
